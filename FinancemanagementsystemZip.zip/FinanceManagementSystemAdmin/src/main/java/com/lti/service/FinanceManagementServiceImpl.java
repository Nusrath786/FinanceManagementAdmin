package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.FinanaceManagementDao;
import com.lti.model.Customer;
import com.lti.model.Login;

@Service("service")
public class FinanceManagementServiceImpl implements FinanaceManagementService {

	@Autowired
	FinanaceManagementDao dao;
	
	@Override
	public boolean addCustomer(Login login) {
		int result = dao.createCustomer(login);
		
		if(result == 1){
			return true;
		}
		else{
			return false;
		}
	
	}

	@Override
	public Login findUser(String username) {
		Login login = dao.viewUser(username);
		System.out.println(login);
		return login ;
	}
	@Override
	public boolean fetchCustomerdetails(Customer customer) {
		int result = dao.displayCustomer(customer);
		
		if(result == 1){
			return true;
		}
		else{
			return false;
		}
	
	}

	@Override
	public Customer displayUser(String username) {
		Customer customer = dao.displayUser(username);
		System.out.println(customer);
		return customer ;
	}

}
